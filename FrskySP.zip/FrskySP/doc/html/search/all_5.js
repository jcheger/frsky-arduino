var searchData=
[
  ['ledset',['ledSet',['../class_frsky_s_p.html#a2fda60419c43a09412be0fb3049c2953',1,'FrskySP']]],
  ['lipocell',['lipoCell',['../class_frsky_s_p.html#a60f08da0348bf72849bd81adeb634c94',1,'FrskySP::lipoCell(uint8_t id, float val)'],['../class_frsky_s_p.html#a6fb4161eb3b2d9c93878824eba4ae20f',1,'FrskySP::lipoCell(uint8_t id, float val1, float val2)']]]
];
