var searchData=
[
  ['myserial',['mySerial',['../class_frsky_s_p.html#a6c42aa9d8c0c6410dae4a47f2b62dbae',1,'FrskySP']]]
];
