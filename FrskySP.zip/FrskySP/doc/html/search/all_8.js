var searchData=
[
  ['senddata',['sendData',['../class_frsky_s_p.html#a5e64663b2b3a6bf2b0cf0afa0cdf49f4',1,'FrskySP::sendData(uint16_t id, int32_t val)'],['../class_frsky_s_p.html#ac36d023ad71b6e6b7cf3fab9bca14aff',1,'FrskySP::sendData(uint8_t type, uint16_t id, int32_t val)']]]
];
