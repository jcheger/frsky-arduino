var searchData=
[
  ['sendcellvolt',['sendCellVolt',['../class_frsky_d.html#a929c9304aacc6aceeed6c5a90a9efc00',1,'FrskyD']]],
  ['senddata',['sendData',['../class_frsky_d.html#a755622d280a41aafcc6de3dcc386c3a9',1,'FrskyD']]],
  ['sendfloat',['sendFloat',['../class_frsky_d.html#a2a0ae3efc42d48ebd1f39a1487002912',1,'FrskyD']]]
];
