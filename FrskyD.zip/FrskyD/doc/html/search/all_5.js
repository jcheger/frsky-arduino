var searchData=
[
  ['myserial',['mySerial',['../class_frsky_d.html#a503ba13043eda599b8a446bfc6eef71d',1,'FrskyD']]]
];
